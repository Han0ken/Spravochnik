﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Справочники
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            abonentsBindingSource.EndEdit();
            abonentsTableAdapter.Update(abonentDataSet.Abonents);
            this.DialogResult = DialogResult.OK;
        }

        private void abonentsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.abonentsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.abonentDataSet);

        }
        public int number;
        private void Form2_Load(object sender, EventArgs e)
        {
            
            this.abonentsTableAdapter.Fill(this.abonentDataSet.Abonents);
            this.abonentsTableAdapter.Fill(this.abonentDataSet.Abonents);
            if (number == -1)
            {
                this.Text = "Добавление абонента";
                abonentsBindingSource.AddNew();
            }
            else
            {
                this.Text = "Редактирование абонента";
                abonentsBindingSource.Position = abonentsBindingSource.Find("idabonent", number);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            abonentsBindingSource.CancelEdit();
            this.DialogResult = DialogResult.Cancel;
        }

        private void abonentsBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.abonentsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.abonentDataSet);

        }
    }
}
