﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Справочники
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void abonentsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.abonentsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.abonentDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            this.abonentsTableAdapter.Fill(this.abonentDataSet.Abonents);
            this.abonentsTableAdapter.Fill(this.abonentDataSet.Abonents);

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.number = -1;
            if (f2.ShowDialog() == DialogResult.OK)
            {
                abonentsTableAdapter.Fill(abonentDataSet.Abonents);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            int n;
            DataRowView dr = (DataRowView)abonentsBindingSource.Current;
            n = Convert.ToInt32(dr["idabonent"]);
            Form2 f2 = new Form2();
            f2.number = n;
            if (f2.ShowDialog() == DialogResult.OK)
                this.abonentsTableAdapter.Fill(this.abonentDataSet.Abonents);
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            DataRowView dr = (DataRowView)abonentsBindingSource.Current;
            string phone = dr["telefon"].ToString();
            string adres = dr["adress"].ToString();
            string fio = dr["FIO"].ToString();
            DialogResult r = MessageBox.Show("Вы действительно хотите удалить \r\n"
                + fio + "\r\n" + adres + "\r\n" + phone, "Удаление абонента!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (r == DialogResult.Yes)
            {
                abonentsDataGridView.Rows.RemoveAt(abonentsBindingSource.Position);
            }
            else
                return;
        }

        private void findFIo_TextChanged(object sender, EventArgs e)
        {
            abonentsBindingSource.Filter = String.Format("FIO LIKE '{0}%'", findFIo.Text);
        }

        private void findTel_TextChanged(object sender, EventArgs e)
        {
            abonentsBindingSource.Filter = String.Format("telefon LIKE '{0}%'", findTel.Text);
        }

        private void abonentsBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.abonentsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.abonentDataSet);

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            abonentsBindingSource.EndEdit();
            abonentsTableAdapter.Update(abonentDataSet.Abonents);
        }
    }
}
